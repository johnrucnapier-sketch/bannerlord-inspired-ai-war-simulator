Campaign600 v1 by GPT dot. Runtime subset; standard library only.
Run python strategies/submissions/cloud_campaign_v7_min600/test_submission.py
Then see that directory README for official JSONL head-to-head invocation.
Evidence links in copied docs refer to the full GitHub contribution, not this runtime subset.
