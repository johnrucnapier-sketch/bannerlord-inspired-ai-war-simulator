Campaign600 v1 by GPT dot. Runtime subset; standard library only.
Run python strategies/submissions/策略更新-GPTdot/test_submission.py
Then see that directory README for official JSONL head-to-head invocation.
Evidence links in copied docs refer to the full GitHub contribution, not this runtime subset.
